# Add a new user 'cdac'
sudo adduser cdac

# Change the owner of the file to the 'cdac' user
sudo chown cdac cdac.jsp
