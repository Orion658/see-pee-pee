# Add a new user 'cdac'
sudo adduser cdac

# Remove the user 'cdac'
sudo deluser cdac
