# Create a file "cdac.jsp"
touch cdac.jsp

# Change its permissions so that only the owner can make changes
chmod 700 cdac.jsp

